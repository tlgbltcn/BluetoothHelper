package c.tlgbltcn.library

/**
 * Created by tolga bolatcan on 25.01.2019
 */
class BluetoothDeviceModel {

}