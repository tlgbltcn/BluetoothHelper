package c.tlgbltcn.bluetoothhelper

import android.bluetooth.BluetoothDevice
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import c.tlgbltcn.library.BluetoothHelper
import c.tlgbltcn.library.BluetoothHelperListener
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(), BluetoothHelperListener {

    private lateinit var bluetoothHelper: BluetoothHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bluetoothHelper = BluetoothHelper(this, this)
            .setPermissionRequired(true)
            .create()

        if (bluetoothHelper.isBluetoothEnabled()) enable_disable.text = "disable"
        else enable_disable.text = "enable"

        if (bluetoothHelper.isBluetoothScanning()) start_stop.text = "stop discovery"
        else start_stop.text = "start discovery"


        enable_disable.setOnClickListener {
            if (bluetoothHelper.isBluetoothEnabled()) {

                bluetoothHelper.disableBluetooth()

            } else {
                bluetoothHelper.enableBluetooth()
            }
        }

        start_stop.setOnClickListener {
            if (bluetoothHelper.isBluetoothScanning()) {
                bluetoothHelper.stopDiscovery()

            } else {
                bluetoothHelper.startDiscovery()
            }
        }
    }

    override fun onStartDiscovery() {
        start_stop.text = "stop discovery"

    }

    override fun onFinishDiscovery() {
        start_stop.text = "start discovery"
    }

    override fun onEnabledBluetooth() {
        enable_disable.text = "disable"
    }

    override fun onDisabledBluetooh() {
        enable_disable.text = "enable"

    }

    override fun getBluetoothDeviceList(device: BluetoothDevice) {
        device
    }

    override fun onResume() {
        super.onResume()
        bluetoothHelper.registerBluetoothStateChanged()
    }


    override fun onStop() {
        super.onStop()
        bluetoothHelper.unregisterBluetoothStateChanged()
    }
}
