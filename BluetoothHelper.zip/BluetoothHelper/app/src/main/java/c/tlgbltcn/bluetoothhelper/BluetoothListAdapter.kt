package c.tlgbltcn.bluetoothhelper



/**
 * Created by tolga bolatcan on 26.01.2019
 */
class BluetoothListAdapter {
}